# Import all functions from dplyr, tidyr, magrittr (bad practice)
# to avoid '::'

#' novelgenes: A package to clean, filter, and analyze data for
#' associations between FUnkSFAM presence and subject metadata.
#'
#' @docType package
#' @name novelgenes
#'
#' @import dplyr
#' @import tidyr
#' @import magrittr
#' @import ggplot2
NULL
