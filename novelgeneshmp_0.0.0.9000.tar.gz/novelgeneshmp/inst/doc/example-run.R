## ---- echo=FALSE, message=FALSE, warning=FALSE---------------------------

knitr::opts_chunk$set(fig.width = 8, fig.height = 8,
                      collapse = TRUE, comment = '#>'
                      )


## ---- warning = FALSE, messages = FALSE----------------------------------

library(novelgeneshmp)


## ---- warning = FALSE, messages = FALSE----------------------------------

library(dplyr)
library(magrittr)
library(ggplot2)


## ------------------------------------------------------------------------

# Specify configuration filename
config_fn = system.file("extdata",
                        "novelgenes_configv.json",
                        package = "novelgeneshmp"
                        )

# Uses jsonlite::fromJSON to load the config into a list
config_l = load_config(config_fn)


## ------------------------------------------------------------------------

# Specify where cleaned data would be
visno_data_fn = system.file("extdata",
                            paste0(config_l$inspect_dir, "visno_mapped_samples_cleaned.tsv"),
                            package = "novelgeneshmp"
                            )
novisno_data_fn = system.file("extdata",
                            paste0(config_l$inspect_dir, "visno_unmapped_samples_cleaned.tsv"),
                            package = "novelgeneshmp"
                            )

# Load the cleaned data
visno_data_df = load_tsv(visno_data_fn)
novisno_data_df = load_tsv(novisno_data_fn)


## ---- echo = FALSE, message = FALSE, warning = FALSE, results = 'hide'----

config_l$span67_fn = system.file("extdata",
                                 "span67.tsv",
                                 package = "novelgeneshmp"
                                 )


## ------------------------------------------------------------------------

# Number of samples per body (sub)site for data that maps to VISNO of origin
# and for data that is not expected to change across VISNOs
nsamples_by_bodysite_df = bind_rows(   # dplyr::bind_rows() is like rbind()
    calc_nsamples_per_group(visno_data_df, 'HMP_BodySite') %>%
        mutate(VISNO_MAPPED = TRUE),
    calc_nsamples_per_group(novisno_data_df, 'HMP_BodySite') %>%
        mutate(VISNO_MAPPED = FALSE)
    )

# FUnkSFAM variation statistics by body (sub)site.
ff_stats_bss_df = calc_FFvariation_per_group(novisno_data_df, 'HMP_BodySubsite')

# Phenotype (subject metadata variable) variation statistics.
ph_stats_bs_df = bind_rows(calc_PHvariation_per_group(visno_data_df, 'HMP_BodySite'),
                           calc_PHvariation_per_group(novisno_data_df, 'HMP_BodySite')
                           )


## ------------------------------------------------------------------------

head(nsamples_by_bodysite_df)
head(ph_stats_bs_df)
head(ff_stats_bss_df)


## ---- warning = FALSE----------------------------------------------------

plot_FFentropy_by_group(ff_stats_bss_df, 'HMP_BodySubsite')


## ---- warning = FALSE----------------------------------------------------

res_by_bodysite_df = bind_rows(
    do_glm_tests(visno_data_df, 'HMP_BodySite'),
    do_glm_tests(novisno_data_df, 'HMP_BodySite')
    )
res_by_bodysubsite_df = bind_rows(
    do_glm_tests(visno_data_df, 'HMP_BodySubsite'),
    do_glm_tests(novisno_data_df, 'HMP_BodySubsite')
    )

head(res_by_bodysite_df)
head(res_by_bodysubsite_df)


## ------------------------------------------------------------------------

# apply all filters
res_bss_fil_df = filter_results_all(res_by_bodysubsite_df, ff_stats_bss_df,
                                    'HMP_BodySubsite', config_l
                                    )

# calls p.adjust(p, method = 'fdr') and sorts the results table
res_bss_df = res_bss_fil_df %>% adjust_pvalues() %>% format_final_results()

head(res_bss_df)


